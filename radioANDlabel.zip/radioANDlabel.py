from tkinter import *
import  tkinter

def salir():
    print("chao")
    monitor.quit()

def seleccionar():
    monitor.config(text="{}".format(opcion.get()))
    monitor.config(text="{}".format(opcion2.get()))

def reset():
    opcion.set(None)
    opcion2.set(None)
    monitor.config(text="")

# Configuración de la raíz

root = Tk()

opcion = IntVar()
label1= tkinter.Label(root, text="Hola usuarios pueden elegir el nombre que mas le guste :)",bg="yellow", fg="blue")
label1.pack(ipadx=20,ipady=20, fill='x')

Radiobutton(root, text="Marina", variable=opcion,value=1, command=seleccionar).pack()
Radiobutton(root, text="Stefa", variable=opcion,value=2, command=seleccionar).pack()
Radiobutton(root, text="Santiago", variable=opcion,value=3, command=seleccionar).pack()
opcion2 = IntVar()
label2= tkinter.Label(root, text="Hola usuarios pueden elegir el coche que mas te guste  :)",bg="yellow", fg="blue")
label2.pack(ipadx=20,ipady=20, fill='x')
Radiobutton(root, text="Ferrari", variable=opcion2,value=4, command=seleccionar).pack()
Radiobutton(root, text="Porche", variable=opcion2,value=5, command=seleccionar).pack()
Radiobutton(root, text="Mclaren", variable=opcion2,value=6, command=seleccionar).pack()



monitor = Label(root)
monitor.pack()
Button(root, text="Reiniciar", command=reset).pack()
Button(root, text="Salir", command=salir).pack()
root.mainloop()
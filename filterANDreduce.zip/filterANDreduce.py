lista = [3, 1, 4, 7, 2, 8, 9, 11, 10]
def even(x):
    return x % 2 != 0
res=list(filter(even, lista))
print(res)
res2= reduce(lambda a,b:a+b,res)
print(res2)
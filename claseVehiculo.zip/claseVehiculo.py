class Vehiculo:
    nombre = None
    precio = None
    recorrido=None

    def __init__(self):
        self.nombre = "kia"
        self.precio = "800000"
        self.recorrido="000 km"


p = Vehiculo()
f= open('vehiculo.txt', 'w')
f.write(p.nombre+'\n')
f.write(p.precio+'\n')
f.write(p.recorrido+'\n')
f.close()
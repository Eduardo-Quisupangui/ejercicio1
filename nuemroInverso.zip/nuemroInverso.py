a= range(1,101)
for inverso in a.__reversed__():
    print(inverso)
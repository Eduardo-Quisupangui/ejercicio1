from tkinter import *
import  tkinter

def salir():
    print("chao")
    monitor.quit()

def seleccionar():
    monitor.config(text="{}".format(opcion.get()))

def reset():
    opcion.set(None)
    monitor.config(text="")

# Configuración de la raíz
root = Tk()

opcion = IntVar()

Radiobutton(root, text="Marina", variable=opcion,value=1, command=seleccionar).pack()
Radiobutton(root, text="Stefa", variable=opcion,value=2, command=seleccionar).pack()
Radiobutton(root, text="Santiago", variable=opcion,value=3, command=seleccionar).pack()
Radiobutton(root, text="Eduardo", variable=opcion,value=4, command=seleccionar).pack()
Radiobutton(root, text="Rebeca", variable=opcion,value=5, command=seleccionar).pack()
Radiobutton(root, text="Leticia", variable=opcion,value=6, command=seleccionar).pack()

monitor = Label(root)
monitor.pack()
Button(root, text="Reiniciar", command=reset).pack()
Button(root, text="Salir", command=salir).pack()
root.mainloop()
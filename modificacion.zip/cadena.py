cadena ="En el Ecuador esta la mitad del mundo "
print(cadena)
print(type(cadena))
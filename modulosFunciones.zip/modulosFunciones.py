import funcionesOpera
def main():
    s= funcionesOpera.suma(2,2)
    r= funcionesOpera.resta(10,3)
    m= funcionesOpera.multi(5,3)
    d= funcionesOpera.divi(10,2)
    print("la suma es ",s)
    print("la resta es ",r )
    print("la multiplicacion es ",m )
    print("la division es ",d )
if __name__ == '__main__':
    main()

#/////////////////////////
def suma(a,b):
    return a+b

def resta(a,b):
    return a-b

def multi(a,b):
    return a*b

def divi(a,b):
    return a/b
f= open('palabras.txt', 'w')
f.write("Santiago\n")
f.write("Eduardo\n")
f.write("Marina\n")
f.write("Stefa\n")

lista=['unalista\n','dos listas\n','tres listas\n','cuatro listas\n','cinco listas\n']
f.writelines(lista)
f.close()
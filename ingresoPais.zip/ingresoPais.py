a=int(input("¿cuantos paises quiere ingresar? "))
scores = []
for p in range(a):
    score = input("ingrese pais ")
    scores.append(score)
print(sorted(scores))
nombre= "Eduardo"
apellido="Lema"
edad="32"
email= "equisupangui@hotmail.com"
telefono="0989885114"
casado= 'false'
hijos = 'false'
lisamigos= ('Diego', 'Oscar', 'Marina', 'Wendy', 'Stefa')
peliculas = {"peli1": 'la tormenta', "peli2": 'la casa del terror', "peli3": 'el bosque'}
print("nombre ",nombre,"apellido",apellido,"edad ",edad,"correo",email,
      "telefono",telefono,"casado ",casado,"hijos",hijos)
print(lisamigos)
print(peliculas)
class Alumno:
    nombre = None
    nota = None

    def __init__(self):
        self.nombre = "Eduardo"
        self.nota = 8


p = Alumno()
if p.nota >= 7:
    print("el alumno ",p.nombre,"aprobado")
else:
    print("el alumno ",p.nombre,"reprobo")
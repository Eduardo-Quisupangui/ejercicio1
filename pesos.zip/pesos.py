n = float(input("Su peso en Kg "))
a = float(input("Su altura en metros "))
est = a
peso = n / est ** 2
peso = round(peso, 2)
print("peso: " + str(peso))

if peso >= 0 and peso <= 15.99:
    print ("Delgadez severa")
elif peso >= 16.00 and peso <= 16.99 :
    print ("Delgadez moderada")
elif peso >= 17.00 and peso <= 18.49:
    print ("Delgadez leve")
elif peso >= 18.50 and peso <= 24.99 :
    print ("Normal")
elif peso >= 25.00 and peso <= 29.99:
    print ("Sobrepeso")
elif peso >= 30.00 and peso <= 34.99:
    print ("obesidad leve")
elif peso >= 35.00 and peso <= 39.00:
    print ("obesidad media")
elif peso >= 40.00:
    print ("obesidad morbida")
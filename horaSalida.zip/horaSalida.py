import datetime
hora = datetime.time(6,0)
hora.hour
hora.minute
print(hora.hour,":",hora.minute)
salida = 19
if hora.hour >= salida :
    print("hora de salida ")
else:
    total=salida-hora.hour
    print("siga trabajando le queda",total,"horas para salir")
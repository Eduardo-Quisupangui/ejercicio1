lista =[2,3,5,7,8]
for impar in lista:
    if impar % 2 != 0:
       print(impar)
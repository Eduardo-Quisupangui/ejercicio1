class Veiculo:
    color = None
    ruedas = None
    puerta = None

    def __init__(self):
        self.color = "Verde"
        self.ruedas = "4"
        self.puertas = "2"
class Coche:
    velocidad = None
    cilindrada = None

    def __init__(self):
        self.velocidad = "250"
        self.cilindrada = "600"

p= Coche()
print("velocidad ",p.velocidad)
print("cilindrada ",p.cilindrada)
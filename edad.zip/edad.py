n = float(input("Ingrese su edad "))

if n >= 18:
    print("usted es mayor de edad")
else:
    print("usted es menor de edad")
def areaTri(b,h):
    a=b*h/2
    return a
res= areaTri(5,3)
print("area del triangulo es ",res)

def areaCirculo(r):
    a=3.1415926535*r**2
    return a
res2= areaCirculo(5)
print("area del circulo es ", res2)
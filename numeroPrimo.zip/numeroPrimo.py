def esprimo(numero):
    for n in range(2, numero):
        if numero % n == 0:
            print("No es primo")
            return False
    print("Es primo")
    return True
esprimo(887)
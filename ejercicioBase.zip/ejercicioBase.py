import sqlite3 as sql

def createDB():
    conn = sql.connect('alumnos.db')
    conn.commit()
    conn.close()
def createTable():
    conn =sql.connect("alumnos.db")
    cursor= conn.cursor()
    cursor.execute(
        """CREATE TABLE alumnos(
        id int,
        nombre text,
        apellido text
        )"""
    )
    conn.commit()
    conn.close()

def insert(id,nombre, apellido):
    conn = sql.connect("alumnos.db")
    cursor = conn.cursor()
    instruccion= f"INSERT INTO alumnos VALUES ({id},'{nombre}','{apellido}')"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()

def ver():
    conn = sql.connect("alumnos.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM alumnos"
    cursor.execute(instruccion)
    datos= cursor.fetchall()
    conn.commit()
    conn.close()
    print(datos)

def inserDatos(streamerlist):
    conn = sql.connect("alumnos.db")
    cursor = conn.cursor()
    instruccion = f"INSERT INTO alumnos VALUES (?,?,?)"
    cursor.executemany(instruccion,streamerlist)
    conn.commit()
    conn.close()

def buscar():
    conn = sql.connect("alumnos.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM alumnos WHERE nombre='Marina'"
    #instruccion = f"SELECT * FROM miaplicacion WHERE subs > 6000"
    cursor.execute(instruccion)
    datos=cursor.fetchall()
    conn.commit()
    conn.close()
    print(datos)

if __name__ == "__main__":

    #createTable()
    #insert(1, "Eduardo", "Lema")
    #ver()
    alumnos = [
        (2,"Andres","Prez"),
        (3, "Andi", "Perez"),
        (4, "Ana", "Prez2"),
        (5, "Andrea", "Prez3"),
        (6, "Anadis", "Prez4"),
        (7, "Marina", "Prez5"),
        (8, "Stefa", "Prez6"),
        (9, "Rebeca", "Prez7")
    ]
    #inserDatos(alumnos)
    buscar()